// ── QTrust popup.js ───────────────────────────────────────────────────────────
// Vanilla JS. No build step. Backend = HuggingFace Space
// ─────────────────────────────────────────────────────────────────────────────

const BACKEND = 'https://kelvinsim24-qtrust-backend.hf.space';

let username   = localStorage.getItem('qtrust_user') || null;
let analysing  = false;
let voted      = null;
let showPass   = false;
let toastTimer = null;
let activePortal = null;   // whichever toast portal is currently visible

// ── SVG snippets ──────────────────────────────────────────────────────────────
const SVG = {
  eye:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  eyeOff: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`,
  check:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  x:      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
  zap:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
  loader: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
  logout: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`,
  arrow:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  badge:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/></svg>`,
  alert:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  flame:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`,
  zapPulse: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="zpulse"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
};

// ── Toast ─────────────────────────────────────────────────────────────────────
function showToast(msg, type = 'info') {
  const portal = activePortal;
  if (!portal) return;
  const icon = type === 'success' ? SVG.check : type === 'error' ? SVG.x : SVG.zap;
  portal.innerHTML = `<div class="toast toast-${type}"><span class="ti">${icon}</span><span class="tm">${msg}</span></div>`;
  requestAnimationFrame(() => {
    const el = portal.querySelector('.toast');
    if (el) requestAnimationFrame(() => el.classList.add('in'));
  });
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    const el = portal.querySelector('.toast');
    if (el) { el.classList.remove('in'); el.classList.add('out'); setTimeout(() => { portal.innerHTML = ''; }, 280); }
  }, 3200);
}

// ── Page switching — with crossfade ──────────────────────────────────────────
function showLogin() {
  const main  = document.getElementById('mainPage');
  const login = document.getElementById('loginPage');
  if (main.style.display !== 'none') {
    main.classList.add('page-exit');
    setTimeout(() => { main.style.display = 'none'; main.classList.remove('page-exit'); }, 220);
  }
  login.style.display = 'flex';
  activePortal = document.getElementById('toastPortalLogin');
}

function showMain() {
  const login = document.getElementById('loginPage');
  const main  = document.getElementById('mainPage');
  if (login.style.display !== 'none') {
    login.classList.add('page-exit');
    setTimeout(() => { login.style.display = 'none'; login.classList.remove('page-exit'); }, 220);
  }
  main.style.display = 'flex';
  activePortal = document.getElementById('toastPortalMain');
}

// ── Main screen inner states ──────────────────────────────────────────────────
function setEmpty() {
  document.getElementById('skeleton').style.display    = 'none';
  document.getElementById('resultCard').style.display  = 'none';
  document.getElementById('emptyState').style.display  = 'flex';
}
function setSkeleton() {
  document.getElementById('emptyState').style.display  = 'none';
  document.getElementById('resultCard').style.display  = 'none';
  document.getElementById('skeleton').style.display    = 'flex';
}
function setResult(msg, trustIndex) {
  document.getElementById('emptyState').style.display = 'none';
  document.getElementById('skeleton').style.display   = 'none';
  const card = document.getElementById('resultCard');
  card.style.display = 'flex';

  // Meter
  const meterWrap = document.getElementById('meterWrap');
  if (trustIndex !== null && trustIndex !== undefined) {
    meterWrap.style.display = 'flex';
    renderMeter(meterWrap, trustIndex);
  } else {
    meterWrap.style.display = 'none';
  }

  document.getElementById('analysisBody').textContent = msg;

  // Reset votes
  voted = null;
  document.getElementById('voteLabel').textContent = 'Agree with this result?';
  const tv = document.getElementById('trueVoteBtn');
  const fv = document.getElementById('fakeVoteBtn');
  tv.classList.remove('voted'); tv.disabled = false;
  fv.classList.remove('voted'); fv.disabled = false;
}

// ── Topbar ────────────────────────────────────────────────────────────────────
function setTopbar(state) {
  const r = document.getElementById('tbRight');
  if (state === 'scanning') {
    r.innerHTML = `<div class="tb-pill tb-scan">${SVG.zapPulse}<span>Analysing…</span></div>`;
  } else {
    const name = (username || '').slice(0, 16);
    r.innerHTML = `
      <div class="tb-user-row">
        <div class="tb-user"><span class="tb-dot"></span><span class="tb-uname">${name}</span></div>
        <button class="btn-out" id="logoutBtn">${SVG.logout}</button>
      </div>`;
    document.getElementById('logoutBtn').addEventListener('click', doLogout);
  }
}

// ── Trust Meter ───────────────────────────────────────────────────────────────
function renderMeter(wrap, value) {
  const R = 46, circ = 2 * Math.PI * R;
  const off = circ - (circ * value / 100);
  let c1, c2, label, cls, icon;
  if (value >= 70)      { c1='#4ade80'; c2='#22c55e'; label='Highly Credible'; cls='v-high'; icon=SVG.badge; }
  else if (value >= 40) { c1='#fbbf24'; c2='#f59e0b'; label='Needs Scrutiny';  cls='v-mid';  icon=SVG.alert; }
  else                  { c1='#fb7185'; c2='#f43f5e'; label='Likely False';    cls='v-low';  icon=SVG.flame; }

  wrap.innerHTML = `
    <div class="meter-wrap">
      <svg viewBox="0 0 100 100" class="meter-svg">
        <defs>
          <linearGradient id="mg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/>
          </linearGradient>
          <filter id="gf"><feGaussianBlur stdDeviation="2.5" result="b"/>
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        </defs>
        <circle cx="50" cy="50" r="${R}" class="m-track"/>
        <circle cx="50" cy="50" r="${R}" class="m-arc" id="mArc"
          stroke="url(#mg)" stroke-dasharray="${circ}" stroke-dashoffset="${circ}"
          filter="url(#gf)" stroke-linecap="round" transform="rotate(-90 50 50)"/>
      </svg>
      <div class="meter-ctr">
        <span class="m-num" id="mNum" style="color:${c1}">0</span>
        <span class="m-pct">%</span>
      </div>
    </div>
    <div class="verdict ${cls}">${icon}<span>${label}</span></div>`;

  requestAnimationFrame(() => setTimeout(() => {
    const arc = document.getElementById('mArc');
    if (arc) { arc.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(.34,1.4,.64,1)'; arc.style.strokeDashoffset = off; }
    const num = document.getElementById('mNum');
    if (num) countUp(num, 0, Math.round(value), 1000);
  }, 60));
}

function countUp(el, from, to, ms) {
  const t0 = performance.now();
  (function step(now) {
    const p = Math.min((now - t0) / ms, 1);
    el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  })(t0);
}

// ── Auth ──────────────────────────────────────────────────────────────────────
async function doLogin() {
  const user = document.getElementById('loginUsername').value.trim();
  const pass = document.getElementById('loginPassword').value;
  if (!user || !pass) { showToast('Enter your credentials', 'error'); return; }

  const btn = document.getElementById('loginBtn');
  btn.disabled = true;
  btn.classList.add('loading');
  btn.innerHTML = `${SVG.loader}<span>Signing in…</span>`;

  try {
    const res  = await fetch(`${BACKEND}/send-login`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ user, pass }),
    });
    const data = await res.json();
    if (res.ok && data.success) {
      username = user;
      localStorage.setItem('qtrust_user', user);
      showToast('Welcome back!', 'success');
      setTimeout(initMain, 500);
    } else {
      showToast('Invalid credentials', 'error');
      resetLoginBtn();
    }
  } catch (e) {
    console.error(e);
    showToast('Cannot reach server', 'error');
    resetLoginBtn();
  }
}

function resetLoginBtn() {
  const btn = document.getElementById('loginBtn');
  btn.disabled = false;
  btn.classList.remove('loading');
  btn.innerHTML = `<span>Sign In</span>${SVG.arrow}`;
}

function doLogout() {
  localStorage.removeItem('qtrust_user');
  username = null; voted = null;
  showToast('Signed out', 'info');
  setTimeout(() => {
    resetLoginBtn();
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
    showLogin();
  }, 500);
}

function togglePw() {
  showPass = !showPass;
  document.getElementById('loginPassword').type = showPass ? 'text' : 'password';
  document.getElementById('pwEye').innerHTML     = showPass ? SVG.eyeOff : SVG.eye;
}

// ── Init main screen ──────────────────────────────────────────────────────────
function initMain() {
  showMain();
  setTopbar('user');
  setEmpty();
  if (typeof chrome !== 'undefined' && chrome?.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const url = tabs[0]?.url || '';
      if (url.includes('x.com') || url.includes('twitter.com')) {
        const inp = document.getElementById('urlInput');
        inp.value = url.split('?')[0];
        inp.classList.add('has-value');
      }
    });
  }
}

// ── Verify ────────────────────────────────────────────────────────────────────
async function doVerify() {
  const url = document.getElementById('urlInput').value.trim();
  if (!url || (!url.includes('x.com') && !url.includes('twitter.com'))) {
    showToast('Enter a valid X / Twitter URL', 'error'); return;
  }
  if (analysing) return;
  analysing = true;

  setTopbar('scanning');
  setSkeleton();
  showToast('Quantum analysis running…', 'info');

  const zap = document.getElementById('zapBtn');
  zap.disabled = true; zap.innerHTML = SVG.loader;

  try {
    const res  = await fetch(`${BACKEND}/send-alert`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ url, username }),
    });
    const data = await res.json();
    if (res.ok) {
      const msg   = data.message || '';
      const match = msg.match(/Trust Index:\s*([\d.]+)%/);
      setResult(msg, match ? parseFloat(match[1]) : null);
      showToast('Analysis complete!', 'success');
    } else {
      showToast(data.error || 'Verification failed', 'error');
      setEmpty();
    }
  } catch (e) {
    console.error(e);
    showToast('Server offline', 'error');
    setEmpty();
  } finally {
    analysing = false;
    setTopbar('user');
    zap.disabled = false; zap.innerHTML = SVG.zap;
  }
}

// ── Vote ──────────────────────────────────────────────────────────────────────
async function doVote(type) {
  const url = document.getElementById('urlInput').value.trim();
  if (!url) { showToast('No URL loaded', 'error'); return; }
  const ep = type === 'true' ? '/send-real-vote' : '/send-fake-vote';
  try {
    const res  = await fetch(`${BACKEND}${ep}`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ url, username }),
    });
    const data = await res.json();
    if (res.ok) {
      voted = type;
      document.getElementById('voteLabel').textContent = '✓ Thank you for your vote';
      const tv = document.getElementById('trueVoteBtn');
      const fv = document.getElementById('fakeVoteBtn');
      tv.disabled = true; fv.disabled = true;
      (type === 'true' ? tv : fv).classList.add('voted');
      showToast(`Voted ${type === 'true' ? 'REAL' : 'FAKE'} ✓`, 'success');
    } else { showToast(data.error || 'Vote failed', 'error'); }
  } catch (e) { console.error(e); showToast('Connection failed', 'error'); }
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // Login page events
  document.getElementById('loginBtn').addEventListener('click', doLogin);
  document.getElementById('pwEye').addEventListener('click', togglePw);
  ['loginUsername','loginPassword'].forEach(id =>
    document.getElementById(id).addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); })
  );

  // Main page events
  document.getElementById('zapBtn').addEventListener('click', doVerify);
  document.getElementById('urlInput').addEventListener('keydown', e => { if (e.key === 'Enter') doVerify(); });
  document.getElementById('urlInput').addEventListener('input', () => {
    const urlEl = document.getElementById('urlInput');
    urlEl.classList.toggle('has-value', urlEl.value.trim().length > 0);
    const card = document.getElementById('resultCard');
    if (card.style.display !== 'none') setEmpty();
    voted = null;
  });

  // Scroll mask — remove fade when scrolled to bottom
  const mainBody = document.querySelector('.main-body');
  if (mainBody) {
    mainBody.addEventListener('scroll', () => {
      const atBottom = mainBody.scrollHeight - mainBody.scrollTop <= mainBody.clientHeight + 4;
      mainBody.classList.toggle('at-bottom', atBottom);
    });
  }
  document.getElementById('trueVoteBtn').addEventListener('click', () => { if (!voted) doVote('true'); });
  document.getElementById('fakeVoteBtn').addEventListener('click', () => { if (!voted) doVote('fake'); });
  document.getElementById('analysisDetails').addEventListener('toggle', function () {
    document.getElementById('analysisCaret').style.transform = this.open ? 'rotate(90deg)' : '';
  });

  // Decide which page to show
  if (username) {
    initMain();
  } else {
    showLogin();
  }
});