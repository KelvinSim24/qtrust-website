from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense, Input, Layer
import tensorflow as tf
import time
from configuration import SystemModule, TerminalMessageColour, model_variation, print_audit
from quantum_circuit_4_inputs import quantum_circuit_4_inputs, visualize_quantum_circuit_4_inputs
from quantum_circuit_8_inputs import quantum_circuit_8_inputs, visualize_quantum_circuit_8_inputs
from quantum_circuit_16_inputs import quantum_circuit_16_inputs, visualize_quantum_circuit_16_inputs
from model_visualization import visualize_training, evaluate_model, visualize_quantum_weights, plot_quantum_circuit_performance
from preprocess import prepare_model_dataset, synth_text, clean_text
from scraping import extract_tweet_details
from firebase_tweet_db import update_ai_index_by_url

num_qubits = 4

# Return Number of Weights depending on Number of Qubit Inputs for Quantum Circuit


def get_weights(num_inputs):
    if num_inputs == 4:
        # 6 Operations
        return num_inputs + (num_inputs/2)
    elif num_inputs == 8:
        # 14 Operations
        return num_inputs + (num_inputs/2) + (num_inputs/2)/2

# Quantum Layer with Flexible Qubit Inputs and Outputs


class QuantumLayer(Layer):
    def __init__(self, num_inputs=num_qubits, num_outputs=num_qubits, **kwargs):
        super(QuantumLayer, self).__init__(**kwargs)
        self.num_inputs = num_inputs
        self.num_outputs = num_outputs

        # Create the weights as a trainable variable in the layer's init
        self.kernel = self.add_weight(
            name='quantum_weights',
            # Ensure int for shape (n Operations * 3 Paramaters)
            shape=(int(get_weights(num_inputs)) * 3,),
            initializer='uniform',
            trainable=True,
            dtype=tf.float64                            # Match the dtype used in the QNode
        )

    def call(self, inputs):
        def process_sample(x):
            # Pass the Quantum Layer's weights to the Quantum Circuits
            if self.num_inputs == 4:
                # Return Quantum 4-Qubits Input Cirucit
                expectations_list = quantum_circuit_4_inputs(
                    x, self.kernel, self.num_outputs)
                return tf.stack([tf.math.real(exp) for exp in expectations_list])
            elif self.num_inputs == 8:
                # Return Quantum 8-Qubits Input Circuit
                expectations_list = quantum_circuit_8_inputs(
                    x, self.kernel, self.num_outputs)
                return tf.stack([tf.math.real(exp) for exp in expectations_list])

        quantum_output = tf.map_fn(
            # Use the helper function to process each sample
            process_sample,
            tf.cast(inputs, dtype=tf.float64),      # Cast inputs to float64
            fn_output_signature=tf.TensorSpec(
                shape=(self.num_outputs,), dtype=tf.float64)
        )
        return tf.cast(quantum_output, dtype=tf.float32)

    def compute_output_shape(self, input_shape):
        # Batch size * Number of outputs
        return (input_shape[0], self.num_outputs)


# Build Hybrid Quantum Model with Flexible Qubit Inputs and Outputs Layer
def build_quantum_model(vocab_size=5000, max_length=150, quantum_inputs=num_qubits, quantum_outputs=num_qubits):
    inputs = Input(shape=(max_length,))

    x = Embedding(vocab_size, 100, input_length=max_length)(inputs)
    x = Conv1D(256, 5, activation='linear')(x)
    x = GlobalMaxPooling1D()(x)

    cnn_output = Dense(quantum_inputs, activation='linear',
                       name='cnn_features')(x)
    quantum_output = QuantumLayer(
        num_inputs=quantum_inputs, num_outputs=quantum_outputs, name='quantum_layer_output')(cnn_output)

    class_output = Dense(1, activation='sigmoid',
                         name='class_pred')(quantum_output)

    model = Model(inputs=inputs, outputs=[class_output, quantum_output])
    return model


# Train Quantum Model
def train_quantum_model(X_train, y_train, X_test, y_test, num_inputs=num_qubits, num_outputs=num_qubits, epochs=5, batch_size=128):

    # Visualize Current Quantum Circuit Layer Configuration
    if num_inputs == 4:
        visualize_quantum_circuit_4_inputs(num_outputs)
    elif num_inputs == 8:
        visualize_quantum_circuit_8_inputs(num_outputs)

    # Buuld the model
    model = build_quantum_model(
        quantum_inputs=num_inputs, quantum_outputs=num_outputs)

    # Compile the Model
    # Update the Loss Dictionary Keys to Match the Model's Actual Output Names
    model.compile(
        optimizer='adam',
        # Use the names defined in build_hybrid_model for outputs
        loss={'class_pred': 'binary_crossentropy',
              'quantum_layer_output': None},
        metrics={'class_pred': 'accuracy'}
    )

    # Print Model Summary to Check Layer Names and Outputs
    print(model.summary())

    start_time = time.time()

    # Train the Model
    print("Training Hybrid QNN Model")

    # Provide targets for both outputs. Use y_train as a dummy target for the quantum output
    # Because we don't have a specific target for the intermediate quantum features
    history = model.fit(
        X_train,
        {
            'class_pred': y_train,     # Class Target
            'quantum_layer_output': tf.zeros_like(y_train, dtype=tf.float32)
        },
        epochs=epochs,
        batch_size=batch_size,
        validation_split=0.1
    )

    end_time = time.time()
    training_time = end_time - start_time
    print(f"\nTotal Training Time: {training_time:.2f} seconds")

    # Plot Training History
    print("Plotting Training")
    visualize_training(history)

    # Evaluation on Test Set
    print("\nEvaluating on Test Set")
    evaluate_model(model, X_test, y_test)

    # Visualize Quantum Weights
    visualize_quantum_weights(model)

    # Quantum-specific Visualizations
    plot_quantum_circuit_performance(history)

    return model


# Train and Save Selected Quantum CNN Model
def train_and_save_quantum_model():
    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"Preparing Training Set", TerminalMessageColour.BLUE.value)

    X_train, X_test, y_train, y_test, tokenizer = prepare_model_dataset()
    print("Train Shape:", X_train.shape, y_train.shape)
    print("Test Shape :", X_test.shape, y_test.shape)

    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"{model_variation.layer_name} Selected", TerminalMessageColour.BLUE.value)

    hybrid_model = train_quantum_model(
        X_train, y_train, X_test, y_test, num_inputs=model_variation.num_inputs, num_outputs=model_variation.num_outputs)
    hybrid_model.save(f"{model_variation.filename}.h5")

    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"AI Model Training Completed", TerminalMessageColour.GREEN.value)


def load_saved_quantum_model():
    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"Initializing AI Model - {model_variation.layer_name}")
    loaded_model = load_model(f"{model_variation.filename}.h5", custom_objects={
                              'QuantumLayer': QuantumLayer})

    print(loaded_model.summary())


def evaluate_url(url):
    tweet_text = extract_tweet_details(url)[0]
    loaded_model = load_model(f"{model_variation.filename}.h5", custom_objects={
                              'QuantumLayer': QuantumLayer})

    tweet_synth, sequences = synth_text(tweet_text)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"{tweet_text}", TerminalMessageColour.RESET.value)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"Text Received", TerminalMessageColour.GREEN.value)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"{clean_text(tweet_text)}", TerminalMessageColour.RESET.value)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"Tweet Text Content Cleaned", TerminalMessageColour.GREEN.value)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"{sequences}", TerminalMessageColour.RESET.value)
    print_audit(f"{SystemModule.TEXT_RECORD.value}",
                f"Tokenized Tweet Text Content Received", TerminalMessageColour.GREEN.value)

    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"Evaluating Tweet {url} with {model_variation.layer_name}", TerminalMessageColour.YELLOW.value)
    trust_index_prob = loaded_model.predict(tweet_synth)[0][0][0]
    trust_index_percentage = trust_index_prob * 100
    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"Tweet URL Link {url} Evaluated with AI Index - {trust_index_percentage:.2f}%", TerminalMessageColour.GREEN.value)
    update_ai_index_by_url(url, float(f"{trust_index_percentage:.2f}"))
    print_audit(f"{SystemModule.AI_MODEL.value}",
                f"Tweet URL Link Credibility Evaluation Completed", TerminalMessageColour.GREEN.value)
