# Importing Libraries
import requests  # type: ignore
from bs4 import BeautifulSoup  # type: ignore
import re
from urllib.parse import urlparse
from configuration import print_audit

# Returns Embeddable HTML from Tweet Link URL


def extract_raw_tweet_oembed(tweet_url):
    oembed_url = f"https://publish.twitter.com/oembed?url={tweet_url}"
    response = requests.get(oembed_url)
    if response.status_code == 200:
        data = response.json()
        return data['html']  # Returns embeddable HTML
    else:
        return None

# Returns Author Username, Tweet Content and Post Date from Tweet Link URL


def extract_tweet_details(tweet_url):
    # Get embed HTML from oEmbed API
    oembed_url = f"https://publish.twitter.com/oembed?url={tweet_url}"
    response = requests.get(oembed_url)

    if response.status_code != 200:
        return None, None, None

    embed_html = response.json().get('html', '')
    soup = BeautifulSoup(embed_html, 'html.parser')

    # Extract tweet text from <p> tag
    tweet_text = soup.find('p').get_text(
        strip=True) if soup.find('p') else None

    # Extract all <a> tags and use the last one for post date
    a_tags = soup.find_all('a')
    post_date = a_tags[-1].get_text(strip=True) if a_tags else None

    # Extract author info from blockquote text
    blockquote = soup.find('blockquote')
    if blockquote:
        text = blockquote.get_text(separator=' ', strip=True)
        match = re.search(r'—\s+(.+?)\s+\(@(.+?)\)', text)
        if match:
            author = f"{match.group(1)} (@{match.group(2)})"
        else:
            author = None
    else:
        author = None

    return tweet_text, post_date, author

# Check if URL is a Tweet URL Link


def is_tweet_url(url):
    """
    Detects if a given URL is a tweet URL or a profile URL.

    Args:
        url (str): The URL to check.

    Returns:
        bool: True if the URL is a tweet URL, False otherwise.
    """
    parsed_url = urlparse(url)
    path_parts = parsed_url.path.strip('/').split('/')

    # A typical tweet URL path structure is '/<username>/status/<tweet_id>'
    # A typical profile URL path structure is '/<username>'
    # We check if the path has at least 3 parts and the second part is 'status'
    print(parsed_url)
    print(path_parts)
    print(url[:5])
    if len(path_parts) >= 3 and path_parts[1].lower() == 'status' and url[:6] == 'https:':
        return True
    else:
        return False


def is_tweet_available(tweet_url):
    """
    Returns True if all three values (tweet_text, post_date, author)
    are present, otherwise returns False.
    """
    tweet_text, post_date, author = extract_tweet_details(tweet_url)

    if tweet_text is not None and post_date is not None and author is not None:
        return True
    else:
        return False
