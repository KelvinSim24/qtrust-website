from flask import jsonify  # type: ignore
from entropy import calculate_adjusted_index
from scraping import extract_raw_tweet_oembed, extract_tweet_details, is_tweet_url
from firebase_paths_db import get_user_id_from_username, get_username_from_user_id
from firebase_tweet_db import get_tweet_entry_metrics, get_user_id_from_url_link
from configuration import DataEntryColumns, TerminalMessageColour, SystemModule, print_audit, model_variation, dev_mode, audit_barrier
from blockchain import generate_blockchain_from_tweet_metadata


# Processes the Final Trust Index Value and then Relay the Information back to the Users
def process_trust_index(url, username):
    # Check if Inserted Scraped URL Link is a Valid Twitter URL Link
    if is_tweet_url(url):
        tweet_text, post_date, author = extract_tweet_details(url)
        html = extract_raw_tweet_oembed(url)
        print(audit_barrier)

        print(f'Tweet HTML: {html}')
        print(f'URL Link:   {url}')
        print(f"Author:     {author}")
        print(f"Tweet Text: {tweet_text}")
        print(f"Post Date:  {post_date}")
        print(audit_barrier)

        print_audit(f"{SystemModule.TRUST_INDEX.value}",
                    f"Preparing Final Trust Index Report - {url}", TerminalMessageColour.YELLOW.value)

        ai_index, real_vote_count, fake_vote_count = get_tweet_entry_metrics(
            url)

        print_audit(f"{SystemModule.TRUST_INDEX.value}",
                    f"Tweet Data Entry Metrics Retrieved - AI Index: {ai_index} | Vote 'Real' Count: {real_vote_count} | Vote 'Fake' Count: {fake_vote_count}", TerminalMessageColour.GREEN.value)
        print_audit(f"{SystemModule.TRUST_INDEX.value}",
                    f"Calculating Final Trust Index", TerminalMessageColour.YELLOW.value)
        trust_index = round(calculate_adjusted_index(
            ai_index, real_vote_count, fake_vote_count), 2)
        print_audit(f"{SystemModule.TRUST_INDEX.value}",
                    f"Trust Index Calculated - {trust_index:.2f}%", TerminalMessageColour.GREEN.value)
        txHash, height, record_hash, chain_error = generate_blockchain_from_tweet_metadata(
            url, author, tweet_text, post_date, ai_index, real_vote_count, fake_vote_count, trust_index, username)

        print_audit(f"{SystemModule.TRUST_INDEX.value}",
                    f"Trust Index Report Generated", TerminalMessageColour.GREEN.value)
        print(audit_barrier)
        print_audit(f"{SystemModule.MAIN_SYS.value}",
                    f"END Check Tweet URL Credibility - {get_user_id_from_username(username)}", TerminalMessageColour.BLUE.value)
        print(audit_barrier)

        if dev_mode:
            result = f"Received URL Link:\n{url}\n\nTrust Index:\n{trust_index}%\n\nCurrent User Logged In: {username}\n\nVote Counts:\nReal - {real_vote_count}, Fake - {fake_vote_count}\n\nAuthor:\n{author}\n\nTweet Text:\n{tweet_text}\n\nPost Date:\n{post_date}\n\nQuantum Model: {model_variation.filename}\n\nSubmitted by {get_user_id_from_url_link(url)}"

            return jsonify({
                "message": result,
                DataEntryColumns.TRUST_INDEX.value: trust_index,
                DataEntryColumns.AI_INDEX.value: ai_index,
                DataEntryColumns.VOTE_REAL_COUNT.value: real_vote_count,
                DataEntryColumns.VOTE_FAKE_COUNT.value: fake_vote_count,
                "txHash": txHash,
                "height": height,
                "record_hash": record_hash
            })

        else:
            result = f'Trust Index:\n{trust_index}%\n\n{say_likelihood(trust_index)}\n\nTweet Text:\n{tweet_text}\n\nVote Counts:\nReal - {real_vote_count} | Fake - {fake_vote_count}\n\nFirst Submitted by {get_username_from_user_id(get_user_id_from_url_link(url))}'
            return jsonify({
                "message": result,
                DataEntryColumns.TRUST_INDEX.value: trust_index,
                DataEntryColumns.AI_INDEX.value: ai_index,
                DataEntryColumns.VOTE_REAL_COUNT.value: real_vote_count,
                DataEntryColumns.VOTE_FAKE_COUNT.value: fake_vote_count,
                "txHash": txHash,
                "height": height,
                "record_hash": record_hash
            })

    else:
        return jsonify({'error': 'Invalid Twitter/X URL'}), 400

# States the likelihood of news authenticity


def say_likelihood(trust_index):
    if trust_index >= 70:
        return 'This Tweet is Most Likely to be REAL'
    elif trust_index >= 30 and trust_index < 70:
        return 'This Tweet is Uncertain'
    elif trust_index >= 0 and trust_index < 30:
        return 'This Tweet is Most Likely to be FAKE'
    else:
        return "ERROR"
